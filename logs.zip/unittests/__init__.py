"""
Test isolation: before any project module is imported, the model and log directories are redirected
to a throw-away temp directory (and every write also uses the test=True flag), so the unit tests can
never read or overwrite the production models in ./models or the production logs in ./logs.
"""
import os
import sys
import atexit
import shutil
import tempfile

_TMP = tempfile.mkdtemp(prefix="aavail-tests-")
os.environ["AAVAIL_MODEL_DIR"] = os.path.join(_TMP, "models")
os.environ["AAVAIL_LOG_DIR"] = os.path.join(_TMP, "logs")
os.environ["AAVAIL_REPORT_DIR"] = os.path.join(_TMP, "reports")
atexit.register(shutil.rmtree, _TMP, ignore_errors=True)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
