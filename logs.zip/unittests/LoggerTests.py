import os
import csv
import unittest

import unittests  # noqa  (redirects log / model dirs to a temp dir)
import logger


class LoggerTest(unittest.TestCase):

    def setUp(self):
        for f in os.listdir(logger.LOG_DIR) if os.path.isdir(logger.LOG_DIR) else []:
            os.remove(os.path.join(logger.LOG_DIR, f))

    def test_log_dir_is_isolated_from_production(self):
        prod = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs")
        self.assertNotEqual(os.path.abspath(logger.LOG_DIR), prod)

    def test_train_log(self):
        logger.update_train_log('all', ('2018-01-01', '2018-12-31'), {'rmse': 0.5}, "00:00:01", 0.1, "note",
                                model_name="ridge", test=True)
        path = os.path.join(logger.LOG_DIR, "train-test.log")
        self.assertTrue(os.path.exists(path))
        rows = logger.read_log("train-test.log")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['tag'], 'all')
        self.assertEqual(rows[0]['model_name'], 'ridge')

    def test_train_log_appends(self):
        for _ in range(3):
            logger.update_train_log('all', ('a', 'b'), {'rmse': 1}, "00:00:01", 0.1, "note", test=True)
        self.assertEqual(len(logger.read_log("train-test.log")), 3)

    def test_predict_log(self):
        logger.update_predict_log('all', 1234.5, None, '2018-01-05', "00:00:01", 0.1, test=True)
        rows = logger.read_log("predict-test.log")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['country'], 'all')
        self.assertEqual(float(rows[0]['y_pred']), 1234.5)
        self.assertEqual(rows[0]['target_date'], '2018-01-05')

    def test_predict_log_header_and_columns(self):
        logger.update_predict_log('germany', 1.0, None, '2018-01-05', "00:00:01", 0.1, test=True)
        with open(os.path.join(logger.LOG_DIR, "predict-test.log")) as f:
            header = next(csv.reader(f))
        self.assertEqual(header, logger.PREDICT_HEADER)

    def test_test_flag_does_not_write_production_files(self):
        logger.update_predict_log('all', 1.0, None, '2018-01-05', "00:00:01", 0.1, test=True)
        self.assertEqual(logger.list_logs(test=False), [])
        self.assertEqual(logger.list_logs(test=True), ["predict-test.log"])

    def test_missing_log_raises(self):
        with self.assertRaises(FileNotFoundError):
            logger.read_log("does-not-exist.log")


if __name__ == '__main__':
    unittest.main()
