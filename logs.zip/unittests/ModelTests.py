import os
import unittest

import numpy as np

import unittests  # noqa  (redirects log / model dirs to a temp dir)
import model
import logger
from cslib import fetch_data, fetch_ts, engineer_features, convert_to_ts

DATA_DIR = model.DATA_DIR


class IngestionTest(unittest.TestCase):

    def test_missing_dir(self):
        with self.assertRaises(Exception):
            fetch_data("/path/that/does/not/exist")

    def test_empty_dir(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(Exception):
                fetch_data(d)

    def test_columns_are_harmonised_and_invoices_numeric(self):
        df = fetch_data(DATA_DIR)
        for col in ('stream_id', 'times_viewed', 'price', 'invoice_date'):
            self.assertIn(col, df.columns)
        for bad in ('StreamID', 'TimesViewed', 'total_price'):
            self.assertNotIn(bad, df.columns)
        self.assertFalse(df['invoice'].str.contains(r"\D").any())

    def test_ts_has_no_gaps(self):
        df = fetch_data(DATA_DIR)
        ts = convert_to_ts(df)
        self.assertTrue((ts['date'].diff().dropna() == np.timedelta64(1, 'D')).all())

    def test_unknown_country(self):
        with self.assertRaises(Exception):
            convert_to_ts(fetch_data(DATA_DIR), country="Atlantis")


class FeatureTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.ts = model.load_ts(DATA_DIR)

    def test_all_and_top_ten_countries(self):
        self.assertIn('all', self.ts)
        self.assertIn('united_kingdom', self.ts)
        self.assertEqual(len(self.ts), 11)

    def test_features_shapes(self):
        X, y, dates = engineer_features(self.ts['all'])
        self.assertEqual(X.shape[0], y.size)
        self.assertEqual(X.shape[0], dates.size)
        self.assertFalse(X.isna().any().any())

    def test_training_flag_removes_last_30_days(self):
        X1, _, d1 = engineer_features(self.ts['all'], training=True)
        X2, _, d2 = engineer_features(self.ts['all'], training=False)
        self.assertEqual(X2.shape[0] - X1.shape[0], 30)

    def test_features_do_not_leak_the_target(self):
        """the previous_7 feature of day t must only use revenue before t"""
        ts = self.ts['all'].copy()
        X, y, dates = engineer_features(ts, training=False)
        i = 100
        d = dates[i]
        manual = ts[(ts['date'] >= np.datetime64(d) - np.timedelta64(7, 'D')) &
                    (ts['date'] < np.datetime64(d))]['revenue'].sum()
        self.assertAlmostEqual(X['previous_7'].iloc[i], manual, places=4)
        manual_y = ts[(ts['date'] >= np.datetime64(d)) &
                      (ts['date'] < np.datetime64(d) + np.timedelta64(30, 'D'))]['revenue'].sum()
        self.assertAlmostEqual(y[i], manual_y, places=4)


class ModelTest(unittest.TestCase):
    """models are trained with test=True: subset of countries, tiny grids, 'test-' files in a temp dir"""

    @classmethod
    def setUpClass(cls):
        cls.trained = model.model_train(DATA_DIR, test=True)
        cls.data, cls.models = model.model_load(prefix="test", training=False)

    def test_model_dir_is_isolated_from_production(self):
        prod = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")
        self.assertNotEqual(os.path.abspath(model.MODEL_DIR), prod)

    def test_train_only_test_countries(self):
        self.assertEqual(sorted(self.trained), sorted(model.TEST_COUNTRIES))

    def test_test_models_have_test_prefix(self):
        files = os.listdir(model.MODEL_DIR)
        self.assertTrue(files and all(f.startswith("test-") for f in files))

    def test_train_wrote_test_train_log_only(self):
        self.assertEqual(logger.list_logs(test=False), [])
        rows = logger.read_log("train-test.log")
        self.assertGreaterEqual(len(rows), len(self.trained))

    def test_multiple_models_were_compared(self):
        comp = self.models['all']['comparison']
        self.assertEqual(set(comp), {'baseline', 'ridge', 'rf', 'gb'})
        self.assertIn(self.models['all']['name'], comp)

    def test_load(self):
        self.assertIn('all', self.models)
        self.assertIn('united_kingdom', self.models)
        self.assertIn('all', self.data)

    def test_predict_all(self):
        res = model.model_predict('all', '2018', '06', '15', all_models=self.models, all_data=self.data, test=True)
        self.assertIsInstance(res['y_pred'], float)
        self.assertGreater(res['y_pred'], 0)

    def test_predict_country(self):
        res = model.model_predict('United Kingdom', '2018', '06', '15', all_models=self.models,
                                  all_data=self.data, test=True)
        self.assertEqual(res['country'], 'united_kingdom')
        self.assertGreater(res['y_pred'], 0)

    def test_predict_next_day_after_data(self):
        last = self.data['all']['dates'][-1]
        nxt = str(np.datetime64(last) + np.timedelta64(1, 'D')).split("-")
        res = model.model_predict('all', *nxt, all_models=self.models, all_data=self.data, test=True)
        self.assertGreater(res['y_pred'], 0)

    def test_predict_is_logged_in_test_log(self):
        before = len(logger.read_log("predict-test.log")) if "predict-test.log" in logger.list_logs(test=True) else 0
        model.model_predict('all', '2018', '06', '16', all_models=self.models, all_data=self.data, test=True)
        self.assertEqual(len(logger.read_log("predict-test.log")), before + 1)
        self.assertEqual(logger.list_logs(test=False), [])

    def test_unknown_country(self):
        with self.assertRaises(ValueError):
            model.model_predict('atlantis', '2018', '06', '15', all_models=self.models, all_data=self.data, test=True)

    def test_bad_date(self):
        with self.assertRaises(ValueError):
            model.model_predict('all', '2018', '13', '45', all_models=self.models, all_data=self.data, test=True)
        with self.assertRaises(ValueError):
            model.model_predict('all', '1999', '01', '01', all_models=self.models, all_data=self.data, test=True)

    def test_baseline_model(self):
        import pandas as pd
        X = pd.DataFrame({'previous_28': [28.0, 56.0]})
        self.assertTrue(np.allclose(model.BaselineModel().fit(X).predict(X), [30.0, 60.0]))


if __name__ == '__main__':
    unittest.main()
