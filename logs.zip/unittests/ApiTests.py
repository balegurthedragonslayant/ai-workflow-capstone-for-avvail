import json
import unittest

import unittests  # noqa  (redirects log / model dirs to a temp dir)
import model
import logger
import app as api


class ApiTest(unittest.TestCase):
    """the API is exercised in test mode ('test': true) - nothing touches production models / logs"""

    @classmethod
    def setUpClass(cls):
        cls.client = api.app.test_client()
        r = cls.client.post("/train", json={"test": True})
        assert r.status_code == 200, r.data

    def predict(self, **body):
        body.setdefault("test", True)
        return self.client.post("/predict", json=body)

    def test_index(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["status"], "ok")

    def test_train(self):
        r = self.client.post("/train", json={"test": True})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(sorted(r.get_json()["trained"]), sorted(model.TEST_COUNTRIES))

    def test_predict_all_countries_combined(self):
        r = self.predict(country="all", date="2018-06-15")
        self.assertEqual(r.status_code, 200)
        body = r.get_json()
        self.assertEqual(body["country"], "all")
        self.assertGreater(body["y_pred"], 0)

    def test_predict_specific_country(self):
        r = self.predict(country="united_kingdom", date="2018-06-15")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["country"], "united_kingdom")

    def test_predict_year_month_day(self):
        r = self.predict(country="all", year="2018", month="06", day="15")
        self.assertEqual(r.status_code, 200)

    def test_all_and_country_differ(self):
        a = self.predict(country="all", date="2018-11-15").get_json()["y_pred"]
        b = self.predict(country="united_kingdom", date="2018-11-15").get_json()["y_pred"]
        self.assertNotEqual(a, b)

    def test_predict_bad_requests(self):
        self.assertEqual(self.client.post("/predict", data="not json").status_code, 400)
        self.assertEqual(self.predict(date="2018-06-15").status_code, 400)             # no country
        self.assertEqual(self.predict(country="all").status_code, 400)                 # no date
        self.assertEqual(self.predict(country="all", date="15/06/2018").status_code, 400)
        self.assertEqual(self.predict(country="all", date="1999-01-01").status_code, 400)
        self.assertEqual(self.predict(country="atlantis", date="2018-06-15").status_code, 400)

    def test_logs_endpoints_use_test_logs(self):
        self.predict(country="all", date="2018-06-15")
        r = self.client.get("/logs?test=true")
        self.assertEqual(r.status_code, 200)
        self.assertIn("predict-test.log", r.get_json())
        self.assertEqual(self.client.get("/logs").get_json(), [])
        r = self.client.get("/logs/predict-test.log")
        self.assertEqual(r.status_code, 200)
        self.assertGreaterEqual(len(r.get_json()), 1)

    def test_missing_log_is_404(self):
        self.assertEqual(self.client.get("/logs/nope.log").status_code, 404)

    def test_monitor(self):
        r = self.client.get("/monitor")
        self.assertEqual(r.status_code, 200)
        self.assertIn("train_log", r.get_json())


if __name__ == '__main__':
    unittest.main()
